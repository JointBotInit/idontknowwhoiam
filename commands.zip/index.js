const Discord = require('discord.js');
const bot = new Discord.Client();
const fs = require('fs');
const config = require('./storage/config.json');
const prefix = config.prefix;
const server = require("./storage/servers.json");
const serverprefix = server.prefix
const art = require('asciiart-logo');
const chalk = require("chalk");
const date = require("date-and-time");
const ms = require("ms");
var request = require("request");
const {
  Client,
  RichEmbed
} = require('discord.js');

exports.bot = bot;
exports.server = server;
bot.commands = new Discord.Collection();

bot.on('error', console.error);

// OnGuild Join
bot.on('guildCreate', async guild => {

  server [guild.id] = {
    serverName: guild.name,
    prefix: `${prefix}`,
    logs: "undefined",
    reports: "undefined",
    adblock: false,
    nsfw: false
  }
  
  let g = bot.guilds.get('500380149787656202');

  let ch = g.channels.get('501916448621330443');

  let now = new Date();
  const edate = date.format(now, 'MMM DD, YYYY');

  let embed = new Discord.RichEmbed()
  .setTitle(`📥 Guild Join | Guilds: ${bot.guilds.size}`)
  .addField(`OwnerID`, `${guild.owner.id}`)
  .addField(`ServerID`, `${guild.id}`)
  .addField(`Members`, `Count: \`${guild.memberCount}\``)
  .addField(`Region`, `${guild.region}`)
  .addField(`Date`, `${edate}`)
  .setThumbnail(guild.iconURL)
  .setColor(config.noembed);

  ch.send(embed);
});

bot.on('message', msg => {
  if (msg.content === `<@484090735298084864> your gay`) {
    msg.reply("Welp... Suppose you didn't think about who your calling that 😠😠😠");
  }
});

bot.on('guildDelete', async guild => {

  delete server[guild.id];
  fs.writeFileSync("./storage/servers.json", JSON.stringify (server));

  let g = bot.guilds.get('500380149787656202');

  let ch = g.channels.get('501916448621330443');

  let now = new Date();
  const edate = date.format(now, 'MMM DD, YYYY');

  let embed = new Discord.RichEmbed()
  .setTitle(`📤 Guild Leave | Guilds: ${bot.guilds.size}`)
  .addField(`OwnerID`, `${guild.owner.id}`)
  .addField(`ServerID`, `${guild.id}`)
  .addField(`Members`, `Count: \`${guild.memberCount}\``)
  .addField(`Region`, `${guild.region}`)
  .addField(`Date`, `${edate}`)
  .setThumbnail(guild.iconURL)
  .setColor(config.noembed);

  ch.send(embed);
});

// Bot isEnabled
bot.on('ready', async () => {

  
    // Command Handler
    const commandFiles = fs.readdirSync("./commands");
    commandFiles.forEach((file) => {
      const command = require(`./commands/${file}`);
      bot.commands.set(command.name, command);
    
    let ops = {
      ownerID: "325375993013338113"
    }
    
    });

    bot.user.setPresence({
      game: {
        name: `?help | Playing with ${bot.users.size} users`,
        type: "STREAMING",
        url: "https://www.twitch.tv/Gigabot"
    }
});
  
});

// Listener
bot.on("message", async(message) => {

  if (message.channel.type != "text") return;
  if (message.author.bot) return;
  const sp =  server [message.guild.id].prefix;
  const args = message.content.slice(sp.length).split(/ +/);
  const command = args.shift();

  if(message.content.includes('http')) {
    if(server[message.guild.id].adblock === false) return;
    if(message.member.hasPermission("MANAGE_GUILD")) return;
    message.delete();
    return;
  }

  if(message.mentions.members.first()) {

    if(message.mentions.members.first().id === '500379363133358100') {

      if(args.length > 0) return;
      message.channel.send(new Discord.RichEmbed().setColor(config.noembed).setDescription(`Bot Prefix: \`${sp}\`\n\nMain Menu: \`${sp}menu\``));
      return;
    }
  }

  if (message.author.bot && message.content.startsWith(sp)) return;
  if (!message.content.startsWith(sp)) return;

  let cmd = bot.commands.get(command.toLowerCase()) || bot.commands.find(cmd => cmd.aliases && cmd.aliases.includes(command.toLowerCase()));
  if (cmd) cmd.execute(message,args);
});

bot.login(config.token);
