const Discord = require('discord.js');
const config = require('../storage/config.json');
const index = require('../index.js');
const bot = index.bot;

module.exports = {
  name: "membercount",
  aliases: ["mc"],
  execute: (message, args) => {

    let b = bot.emojis.get('500839921477615626');

    let total = message.guild.memberCount;
    let users = message.guild.members.filter(u => u.user.bot === false).size
    let bots = message.guild.members.filter(u => u.user.bot === true).size

    let embed = new Discord.RichEmbed()
    .addField(`👥 Total`, `Count: \`${total}\``, true)
    .addField(`👨 Humans`, `Count \`${users}\``, true)
    .addField(`${b} Bots`, `Count \`${bots}\``, true)
    .setColor(config.noembed);

    message.channel.send(embed);
  }
}
