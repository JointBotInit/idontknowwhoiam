const Discord = require('discord.js');
const config = require('../storage/config.json');
const index = require('../index.js');
const bot = index.bot;

module.exports = {
  name: "store",
  aliases: ["shop"],
  execute: async (message, args) => {

    message.channel.send({files: ['./storage/Shop.jpg']});
  }
}
