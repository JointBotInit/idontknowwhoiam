const Discord = require('discord.js');
const config = require('../storage/config.json');
const index = require("../index.js");
const bot = index.bot;
const server = index.server;
const fs = require("fs");
const {
    Client,
    RichEmbed
  } = require('discord.js');

  module.exports = {
    name: "unreleasedcosmetics",
    aliases: ["upcomingcosmetics"],
    execute: async (message, args) => {

    var request = require("request");
    var options = { method: 'GET',
      url: 'https://fnbr.co/api/upcoming',
      headers: 
       { 'cache-control': 'no-cache',
         'x-api-key': '31c4e0bf-60c1-4e56-b344-ec87a6dc2270' } };
    
    
    var fnbrapi;
    request(options, function (error, response, body) {
      if (error) throw new Error(error);
    
      fnbrapi = JSON.parse(body);  
        fnbrapi.data    .forEach(data => {
            const embed = new RichEmbed()
                .setTitle(data.name)
                .setColor(0xFF0000)
                .setDescription(data.description)
                .setThumbnail(data.images.icon);
            message.channel.send(embed);
            //msg.channel.send('test');
            //msg.reply('Current news' + data.body);
        });
    });
    }};
module.exports.help = {
    name: "testing"
}