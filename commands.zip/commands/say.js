const Discord = require('discord.js');
const config = require('../storage/config.json');
const index = require("../index.js");
const bot = index.bot;

module.exports = {
  name: "say",
  execute: (message, args) => {

    let err = bot.emojis.get('500814919344717854');

    if(!message.member.hasPermission("ADMINISTRATOR")) {

      let embed = new Discord.RichEmbed()
      .setAuthor(`${message.author.username}#${message.author.discriminator}`)
      .setDescription(`${err} **Insufficient Permission**\n\nMissing Permission - \`ADMINISTRATOR\``)
      .setColor(config.error);
      message.channel.send(embed);
      return;
    }

    if(!args[0]) {
      message.delete();
      message.author.send(`${err} • Please specify something to say.`);
      return;
    }
    message.delete();
    message.channel.send(args.join(" ").slice(0));
  }
}
