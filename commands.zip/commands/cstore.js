const jimp = require("jimp");
const chalk = require('chalk');
const rp = require('request-promise');
const config = require("../storage/config.json");
const Discord = require("discord.js");

module.exports = {
  name: "cstore",
  execute: async (message, args) => {

    if(!message.member.roles.some(r=>config.admin_role.includes(r.name))) return message.channel.send(new Discord.RichEmbed().setColor("RED").setTitle(`${message.author.username}#${message.author.discriminator}`).setDescription(`:x: **Insufficient Permission**\n\nMissing Permission - \`${config.admin_role}\``));

    console.log(chalk.yellow(`- Checking for updates...`));

    message.delete();

    async function createShop() {

      Promise.all([
        rp({
          uri:"https://fnbr.co/api/shop",
          headers: {
            "x-api-key":"31c4e0bf-60c1-4e56-b344-ec87a6dc2270"
          }
        }),

      jimp.read("./storage/Images/shopBack.png"),
      jimp.read("./storage/Images/rarities/uncommon.png"),
      jimp.read("./storage/Images/rarities/rare.png"),
      jimp.read("./storage/Images/rarities/epic.png"),
      jimp.read("./storage/Images/rarities/legendary.png"),
      jimp.read("./storage/Images/backdrop.png"),
      jimp.loadFont("./storage/Fonts/open-sans-32-white.fnt"),
      jimp.loadFont("./storage/Fonts/open-sans-28-white.fnt"),
      jimp.loadFont("./storage/Fonts/open-sans-60-white.fnt"),
      jimp.loadFont("./storage/Fonts/open-sans-92-white.fnt"),

    ])
    .then(values => {

      let [, shopImage, uncommonImage, rareImage, epicImage, legendaryImage, backDrop, font32, font28, titleFont, mainTitle] = values;
      let imageMap = {uncommon: uncommonImage, rare: rareImage, epic: epicImage, legendary: legendaryImage};
      let shop = JSON.parse(values[0]);
      let daily = shop.data.daily;
      let featured = shop.data.featured;
      let dailyImgs = Promise.all(daily.map(obj => jimp.read(obj.images.icon)));
      let featImgs = Promise.all(featured.map(obj => jimp.read(obj.images.icon)));
      return Promise.all([
          dailyImgs,
          featImgs,
          values,
          daily,
          featured,
          imageMap
        ]);
    })
    .then(shopImages => {
      let [dailyImgs, featImgs, [, shopImage,,,,, backDrop, font32, font28, titleFont, mainTitle], daily, featured, imageMap] = shopImages;

      let i = 0;
      let iconSize = 225;
      let rarityDiff = 25;
      let xPad = 150;
      let yPad = 250;
      let columns = 3;
      let infoBoxHeight = 80;
      let width = shopImage.bitmap.width, height = shopImage.bitmap.height;

      let Title = "Gigabot's Fortnite Store!";
      let titleWidth = jimp.measureText(mainTitle, Title);
      let dailyWidth = jimp.measureText(titleFont, "Daily Item's");
      let featuredWidth = jimp.measureText(titleFont, "Featured Item's");
      shopImage.print(mainTitle, Math.floor(width / 2 - titleWidth / 2), 50, Title)
        .print(titleFont, Math.floor((iconSize*columns + rarityDiff*3 + 280) / 2 - dailyWidth / 2), yPad-90, "Daily Items")
        .print(titleFont, Math.floor(width-(iconSize*columns + rarityDiff*3 + 390)  / 2 - featuredWidth / 2), yPad-90, "Featured Items");


      dailyImgs.map(x => {
        let itemNameWidth = jimp.measureText(font32, daily[i].name);
        let itemPriceWidth = jimp.measureText(font28, daily[i].price + " V-Bucks");
        x.resize(iconSize, iconSize);
        let infoBox = backDrop.clone()
          .resize(iconSize, infoBoxHeight)
          .print(font32, Math.floor(iconSize / 2 - itemNameWidth / 2), 5, daily[i].name)
          .print(font28, Math.floor(iconSize / 2 - itemPriceWidth / 2), 40, daily[i].price + " V-Bucks");
        let rarityImage = imageMap[daily[i].rarity]
          .clone()
          .resize(iconSize, iconSize)
          .quality(80)
          .composite(x, 0, 0)
          .composite(infoBox, 0, iconSize-infoBoxHeight);
        shopImage.composite(rarityImage, (i%columns)*(iconSize+rarityDiff)+xPad, Math.floor(i/columns)*(iconSize+rarityDiff)+yPad);
        i++;
      });

      i = 0;
      featImgs.map(x => {
        let itemNameWidth = jimp.measureText(font32, featured[i].name);
        let itemPriceWidth = jimp.measureText(font28, featured[i].price + " V-Bucks");
        x.resize(iconSize, iconSize);
        let infoBox = backDrop.clone()
          .resize(iconSize, infoBoxHeight)
          .print(font32, Math.floor(iconSize / 2 - itemNameWidth / 2), 5, featured[i].name)
          .print(font28, Math.floor(iconSize / 2 - itemPriceWidth / 2), 40, featured[i].price + " V-Bucks");
        let rarityImage = imageMap[featured[i].rarity]
          .clone()
          .quality(80)
          .resize(iconSize, iconSize)
          .composite(x, 0, 0)
          .composite(infoBox, 0, iconSize-infoBoxHeight);
        shopImage.composite(rarityImage, width-((i%columns)*(iconSize+rarityDiff)+xPad*2+(iconSize+rarityDiff)/2), Math.floor(i/columns)*(iconSize+rarityDiff)+yPad);
        i++;
      });
      shopImage.quality(100)
        .write("./storage/Shop.jpg");
      console.log(chalk.cyan(`- Shop Updated!`));
    });
  } setInterval(createShop, 1000)
}
}
